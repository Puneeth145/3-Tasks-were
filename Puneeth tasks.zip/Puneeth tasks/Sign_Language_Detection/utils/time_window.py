import datetime
def within_time_window():
    now=datetime.datetime.now()
    start_time=now.replace(hour=18,minute=0,second=0,microsecond=0)
    end_time=now.replace(hour=22,minute=0,second=0,microsecond=0)
    return start_time<=now<=end_time