import cv2
import numpy as np
def preprocess_image(image):
    image=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
    image=cv2.resize(image,(64,64))
    image=image.astype('float32')/255
    image=np.expand_dims(image,axis=0)
    image=np.expand_dims(image,axis=-1)
    return image