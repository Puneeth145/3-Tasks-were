# Sign Language Detection System Project README

## Project Overview
The Sign Language Detection System is an advanced machine learning project designed to recognize specific hand gestures in sign language. The system allows for real-time detection of sign language through a webcam feed or from uploaded images and logs the recognized signs into a CSV file. It operates within a specified time window and is built with an interactive GUI to provide an intuitive user experience.

## Project Directory Structure
- `data/`
  - `signs/`: Contains images of hand signs organized in folders named after each sign.
  
- `models/`
  - `sign_language_model.h5`: The trained machine learning model for recognizing sign language.

- `attendance.csv`: Logs detected signs along with confidence levels and timestamps.

- `Sign_Language_Detection.ipynb`: Jupyter Notebook containing code for preprocessing, training, and saving the sign language detection model.

- `detection.py`: Python script for loading the trained model, detecting signs from images or webcam, and logging detected signs into the CSV file.

- `gui.py`: Python script that launches the graphical user interface (GUI) for real-time sign detection and image uploads.

- `utils/`
  - `preprocess.py`: Contains image preprocessing utilities for preparing the images before model prediction.
  - `time_window.py`: Defines the allowed operational time window for detection.

- `requirements.txt`: List of Python dependencies required to run the project.

- `README.md`: Documentation for the project.


## Getting Started

To get started with the project, follow these steps:

### Clone the Repository

Clone the project repository to your local machine using:

```bash
git clone <repository-url>

### Install Dependencies

Navigate to the project directory and install the required Python packages using:

```bash
pip install -r requirements.txt


## Prepare Data
- Place sign language gesture images in `data/signs/` with folders named after each sign.

## Train Models
- Open the `Sign_Language_Detection.ipynb` notebook and execute the cells to preprocess data and train the sign language detection model. After training, ensure the model is saved in the `models/` directory.

## Run the Sign Language Detection System

### Image Upload Mode:
1. Run the `gui.py` script to launch the GUI.
2. Click "Upload Image" in the GUI and select an image to detect the sign.
3. The detected sign and confidence level will be displayed in the GUI.

### Real-Time Video Mode:
1. Run the `gui.py` script and click "Real-Time Detection" to start the webcam-based sign detection.
2. Detected signs will appear on the screen in real-time.
3. The system will automatically log recognized signs into `attendance.csv`.

## Check Logs
- The `attendance.csv` file will store the detected signs, confidence levels, and the corresponding timestamps.

## GUI Overview
The GUI (`gui.py`) provides a user-friendly interface with the following features:
- **Upload Image**: Allows the user to upload an image for sign language detection.
- **Real-Time Detection**: Initiates real-time sign detection through a webcam.
- **Logs**: Displays the detected signs and confidence levels from the real-time or image-based detection.
- **Time Control**: Ensures the detection process runs only during the specified operational hours.

## Scripts Overview
- **Sign_Language_Detection.ipynb**: Contains code for preprocessing data, training the sign language detection model, and saving the trained model.

- **detection.py**: Loads the trained model and handles sign detection for both image and real-time video inputs. Logs the detected signs and confidence levels to `attendance.csv`.

- **gui.py**: Implements the graphical user interface for the project, integrating real-time and image-based sign detection functionalities.

- **utils/preprocess.py**: Handles image preprocessing (resizing, normalization) to ensure consistency in input data for the model.

- **utils/time_window.py**: Verifies if the current time falls within the allowed operational window for detection.

## Dependencies
The project relies on the following Python packages:
- `tensorflow`: For building and using the machine learning model.
- `opencv-python`: For image and video processing.
- `tkinter`: For creating the graphical user interface.
- `numpy`: For numerical operations.
- `pandas`: For logging the results to CSV.
- `scikit-learn`: For machine learning utilities and metrics.

## Usage

### Training Models:
- Open and execute the Jupyter Notebook `Sign_Language_Detection.ipynb` to preprocess the dataset and train the model.

### Detection (Image Upload):
- Run `gui.py` and use the upload image feature to detect signs from an image file.

### Detection (Real-Time):
- Use the real-time detection feature in `gui.py` to recognize signs from the webcam feed. The system will only operate within the specified time window.

## Troubleshooting
- Ensure all dependencies are correctly installed as per the `requirements.txt`.
- Verify that the folder structure for the images and models is correctly maintained.
- If the system does not detect signs, ensure the image/video resolution matches the input dimensions expected by the model.
- Check the specified time window in `time_window.py` to ensure the system is running during the allowed operational hours.

## Future Enhancements
- **Extended Sign Vocabulary**: Add more sign gestures to the dataset to improve model performance and extend the vocabulary.
- **Mobile App Integration**: Expand the system to work on mobile platforms for better accessibility.
- **Performance Optimization**: Optimize the model for faster inference in real-time detection.
