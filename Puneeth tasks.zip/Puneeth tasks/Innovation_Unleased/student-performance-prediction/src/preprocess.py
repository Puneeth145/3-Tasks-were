import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
def load_and_preprocess_data(filepath):
    data=pd.read_csv(filepath)
    data.dropna(inplace=True)
    data.drop(columns=['school','sex','address'],inplace=True)
    data=pd.get_dummies(data,drop_first=True)
    X=data.drop(columns=['G3'])
    y=data['G3']
    X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2,random_state=42)
    scaler=StandardScaler()
    X_train_scaled=scaler.fit_transform(X_train)
    X_test_scaled=scaler.transform(X_test)
    processed_data=pd.DataFrame(X_train_scaled)
    processed_data.to_csv('../data/processed/X_train.csv',index=False)
    return X_train_scaled,X_test_scaled,y_train,y_test,scaler