from joblib import load
from sklearn.metrics import mean_squared_error,r2_score
import numpy as np
import matplotlib.pyplot as plt
from preprocess import load_and_preprocess_data
def evaluate_model(data_filepath):
    model=load('../models/final_model.pkl')
    scaler=load('../models/scaler.pkl')
    X_train,X_test,y_train,y_test,_=load_and_preprocess_data(data_filepath)
    y_pred=model.predict(X_test)
    mse=mean_squared_error(y_test,y_pred)
    rmse=np.sqrt(mse)
    r2=r2_score(y_test,y_pred)
    print(f"\nEvaluation Metrics for Final Model:")
    print(f"Mean Squared Error (MSE): {mse:.4f}")
    print(f"Root Mean Squared Error (RMSE): {rmse:.4f}")
    print(f"R^2 Score: {r2:.4f}")
    residuals=y_test-y_pred
    plt.figure(figsize=(10,6))
    plt.scatter(y_pred,residuals,alpha=0.5,color='blue')
    plt.axhline(y=0,color='red',linestyle='--')
    plt.xlabel('Predicted Values')
    plt.ylabel('Residuals')
    plt.title('Residuals vs Predicted Values')
    plt.show()
    if hasattr(model,'feature_importances_'):
        importances=model.feature_importances_
        feature_names=X_train.columns
        indices=np.argsort(importances)[::-1]
        plt.figure(figsize=(12,8))
        plt.title('Feature Importances')
        plt.bar(range(X_train.shape[1]),importances[indices],align='center')
        plt.xticks(range(X_train.shape[1]),np.array(feature_names)[indices],rotation=90)
        plt.xlim([-1,X_train.shape[1]])
        plt.show()

if __name__=="__main__":
    data_filepath='../data/raw/student-mat.csv'
    evaluate_model(data_filepath)