from sklearn.linear_model import LinearRegression,Ridge,Lasso
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error,r2_score
from preprocess import load_and_preprocess_data
from joblib import dump
import numpy as np
def train_model(data_filepath):
    X_train,X_test,y_train,y_test,scaler=load_and_preprocess_data(data_filepath)
    models={
        "Linear Regression":LinearRegression(),
        "Ridge Regression":Ridge(alpha=1.0),
        "Lasso Regression":Lasso(alpha=0.1),
        "Random Forest":RandomForestRegressor(n_estimators=100,random_state=42)
    }
    for name,model in models.items():
        print(f"\nTraining {name}...")
        model.fit(X_train,y_train)
        y_pred=model.predict(X_test)
        mse=mean_squared_error(y_test,y_pred)
        rmse=np.sqrt(mse)
        r2=r2_score(y_test,y_pred)
        print(f"{name} -- RMSE: {rmse:.4f}, R^2: {r2:.4f}")
    best_model=models["Random Forest"]
    dump(best_model,'../models/final_model.pkl')
    dump(scaler,'../models/scaler.pkl')
    print("\nBest model saved to '../models/final_model.pkl'")